import { createRouter, createWebHashHistory } from 'vue-router';
import DashboardView from './views/DashboardView.vue';
import PurchasesView from './views/PurchasesView.vue';
import PurchaseFormView from './views/PurchaseFormView.vue';
import PurchaseDetailView from './views/PurchaseDetailView.vue';
import SuppliersView from './views/SuppliersView.vue';
import PaymentFormView from './views/PaymentFormView.vue';
import LegalView from './views/LegalView.vue';
import NotFoundView from './views/NotFoundView.vue';

export default createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: '/dashboard' },
    { path: '/dashboard', component: DashboardView, meta: { title: 'nav.dashboard' } },
    { path: '/purchases', component: PurchasesView, meta: { title: 'nav.purchases' } },
    { path: '/purchases/new', component: PurchaseFormView, meta: { title: 'purchase.new' } },
    { path: '/purchases/:id', component: PurchaseDetailView, meta: { title: 'purchase.details' } },
    { path: '/purchases/:id/payments/new', component: PaymentFormView, meta: { title: 'payment.new' } },
    { path: '/suppliers', component: SuppliersView, meta: { title: 'nav.suppliers' } },
    { path: '/terms', component: LegalView, meta: { title: 'legal.terms' } },
    { path: '/privacy', component: LegalView, meta: { title: 'legal.privacy' } },
    { path: '/:pathMatch(.*)*', component: NotFoundView, meta: { title: 'common.notFound' } },
  ],
  scrollBehavior: () => ({ top: 0 }),
});
