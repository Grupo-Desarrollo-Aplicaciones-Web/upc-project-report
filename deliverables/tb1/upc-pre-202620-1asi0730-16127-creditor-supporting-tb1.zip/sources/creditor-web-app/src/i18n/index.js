import { ref } from 'vue';
import en from './en.js';
import es from './es.js';

const resources = { 'en-US': en, 'es-419': es };
let saved;
try { saved = localStorage.getItem('creditor.locale'); } catch { /* Language falls back to English when storage is unavailable. */ }
export const locale = ref(saved in resources ? saved : 'en-US');
export function setLocale(value) {
  locale.value = value in resources ? value : 'en-US';
  try { localStorage.setItem('creditor.locale', locale.value); } catch { /* Current session remains usable. */ }
}
export function t(key, values = {}) {
  const template = key.split('.').reduce((value, part) => value?.[part], resources[locale.value]);
  if (typeof template !== 'string') throw new Error(`Missing translation: ${key}`);
  return template.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ''));
}
export function formatMoney(cents, currency) {
  return new Intl.NumberFormat(locale.value, { style: 'currency', currency }).format(cents / 100);
}
export function formatDate(value) {
  return new Intl.DateTimeFormat(locale.value, { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(`${value}T12:00:00`));
}
