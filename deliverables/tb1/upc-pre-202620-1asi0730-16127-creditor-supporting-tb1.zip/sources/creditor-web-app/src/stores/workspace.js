import { reactive, readonly } from 'vue';
import { createLocalRepository } from '../data/local-repository.js';
let repository;
const state = reactive({ suppliers: [], purchases: [], payments: [], loading: true, error: null, notice: null });

function adapter() {
  if (!repository) {
    try { repository = createLocalRepository(window.localStorage); }
    catch { throw new Error('common.storageError'); }
  }
  return repository;
}
export function loadWorkspace() {
  state.loading = true;
  state.error = null;
  try { Object.assign(state, adapter().load()); }
  catch (error) { state.error = error.key || error.message || 'common.storageError'; }
  finally { state.loading = false; }
}
export function useWorkspace() {
  if (state.loading) loadWorkspace();
  return {
    state: readonly(state),
    reload: loadWorkspace,
    async addPurchase(input) { const purchase = adapter().addPurchase(input); loadWorkspace(); state.notice = 'purchase.registered'; return purchase; },
    async addSupplier(input) { const supplier = adapter().addSupplier(input); loadWorkspace(); state.notice = 'supplier.saved'; return supplier; },
    async addPayment(purchaseId, input) { const payment = adapter().addPayment(purchaseId, input); loadWorkspace(); state.notice = 'payment.saved'; return payment; },
    reset() { adapter().reset(); loadWorkspace(); state.notice = 'common.resetDone'; },
    clearNotice() { state.notice = null; },
  };
}
