import { parseAmount, balanceCents } from './money.js';
import { validDate, today } from './dates.js';

export function validatePayment(input, purchase, payments, organizationId) {
  const errors = {};
  if (!purchase || purchase.organizationId !== organizationId) return { purchaseId: 'errors.tenant' };
  const amount = parseAmount(input.amount);
  if (amount === null) errors.amount = 'errors.amount';
  else if (balanceCents(purchase, payments) === 0) errors.amount = 'errors.settled';
  else if (amount > balanceCents(purchase, payments)) errors.amount = 'errors.overpayment';
  if (input.currency !== purchase.currency) errors.currency = 'errors.currency';
  if (!validDate(input.paidOn)) errors.paidOn = 'errors.date';
  else if (input.paidOn < purchase.purchasedOn) errors.paidOn = 'errors.tooEarly';
  else if (input.paidOn > today()) errors.paidOn = 'errors.futureDate';
  if (String(input.note || '').length > 200) errors.note = 'errors.note';
  return errors;
}
