export const MAX_AMOUNT_CENTS = 999_999_999;
export const CURRENCIES = ['PEN', 'USD'];

export function parseAmount(value) {
  const text = String(value ?? '').trim().replace(',', '.');
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(text)) return null;
  const [whole, fraction = ''] = text.split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  return cents > 0 && cents <= MAX_AMOUNT_CENTS ? cents : null;
}

export function paidCents(purchase, payments) {
  return payments.filter(payment => payment.purchaseId === purchase.id && payment.organizationId === purchase.organizationId).reduce((sum, payment) => sum + payment.amountCents, 0);
}
export function balanceCents(purchase, payments) { return purchase.amountCents - paidCents(purchase, payments); }

export function summarizeByCurrency(purchases, payments) {
  return CURRENCIES.map(currency => {
    const records = purchases.filter(purchase => purchase.currency === currency);
    const amountCents = records.reduce((sum, purchase) => sum + purchase.amountCents, 0);
    const paid = records.reduce((sum, purchase) => sum + paidCents(purchase, payments), 0);
    return { currency, amountCents, paidCents: paid, balanceCents: amountCents - paid, count: records.filter(purchase => balanceCents(purchase, payments) > 0).length };
  });
}
