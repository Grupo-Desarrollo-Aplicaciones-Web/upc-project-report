export const FILE_TYPES = ['application/pdf', 'image/png', 'image/jpeg'];
export const MAX_FILE_BYTES = 2 * 1024 * 1024;
export function validateFile(file) {
  if (!file) return null;
  if (!FILE_TYPES.includes(file.type)) return 'errors.fileType';
  if (!Number.isInteger(file.size) || file.size <= 0 || file.size > MAX_FILE_BYTES) return 'errors.fileSize';
  return null;
}
export async function readVoucher(file) {
  if (!file) return null;
  const error = validateFile(file);
  if (error) throw new Error(error);
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('errors.fileRead'));
    reader.onload = () => resolve({ name: file.name.slice(0, 150), type: file.type, size: file.size, dataUrl: reader.result });
    reader.readAsDataURL(file);
  });
}
export function validVoucher(voucher) {
  if (voucher === null || voucher === undefined) return true;
  return typeof voucher.name === 'string' && voucher.name.length <= 150 && !validateFile(voucher) && typeof voucher.dataUrl === 'string' && new RegExp(`^data:${voucher.type.replace('/', '\\/')};base64,[A-Za-z0-9+/]+=*$`).test(voucher.dataUrl) && voucher.dataUrl.length <= Math.ceil(MAX_FILE_BYTES / 3) * 4 + 100;
}
