import { balanceCents, CURRENCIES, parseAmount } from './money.js';
import { validDate, today, dayDifference } from './dates.js';

export function validatePurchase(input, suppliers, organizationId, purchases = []) {
  const errors = {};
  if (!suppliers.some(supplier => supplier.id === input.supplierId && supplier.organizationId === organizationId)) errors.supplierId = 'errors.supplier';
  if (!CURRENCIES.includes(input.currency)) errors.currency = 'errors.currency';
  if (parseAmount(input.amount) === null) errors.amount = 'errors.amount';
  if (!validDate(input.purchasedOn)) errors.purchasedOn = 'errors.date';
  else if (input.purchasedOn > today()) errors.purchasedOn = 'errors.futureDate';
  if (!validDate(input.dueOn)) errors.dueOn = 'errors.date';
  else if (validDate(input.purchasedOn) && input.dueOn < input.purchasedOn) errors.dueOn = 'errors.dueDate';
  const reference = String(input.reference ?? '').trim();
  if (reference.length < 2 || reference.length > 80) errors.reference = 'errors.reference';
  else if (purchases.some(purchase => purchase.organizationId === organizationId && purchase.supplierId === input.supplierId && purchase.reference.toLowerCase() === reference.toLowerCase())) errors.reference = 'errors.duplicate';
  const description = String(input.description ?? '').trim();
  if (description.length < 3 || description.length > 200) errors.description = 'errors.description';
  return errors;
}
export function purchaseStatus(purchase, payments, reference = today()) {
  if (balanceCents(purchase, payments) === 0) return 'settled';
  const days = dayDifference(purchase.dueOn, reference);
  if (days < 0) return 'overdue';
  if (days <= 7) return 'dueSoon';
  return 'pending';
}
export function filterPurchases(purchases, suppliers, payments, filters) {
  const query = String(filters.query || '').toLowerCase().trim();
  return purchases.filter(purchase => {
    const supplier = suppliers.find(item => item.id === purchase.supplierId);
    const content = `${supplier?.name} ${purchase.reference} ${purchase.description}`.toLowerCase();
    return (!query || content.includes(query)) && (!filters.supplierId || purchase.supplierId === filters.supplierId) && (!filters.currency || purchase.currency === filters.currency) && (!filters.status || purchaseStatus(purchase, payments) === filters.status) && (!filters.dueFrom || purchase.dueOn >= filters.dueFrom) && (!filters.dueTo || purchase.dueOn <= filters.dueTo);
  }).sort((a, b) => a.dueOn.localeCompare(b.dueOn));
}
export function validateSupplier(input) {
  const errors = {};
  const name = String(input.name ?? '').trim();
  if (name.length < 2 || name.length > 100) errors.name = 'errors.name';
  if (input.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email)) errors.email = 'errors.email';
  if ((input.taxId || '').length > 30) errors.taxId = 'errors.taxId';
  if ((input.phone || '').length > 30) errors.phone = 'errors.phone';
  return errors;
}
