<script setup>
import { watch, ref, nextTick } from 'vue';
import { useRoute } from 'vue-router';
import Button from 'primevue/button';
import WorkspaceStatus from './components/WorkspaceStatus.vue';
import { locale, setLocale, t } from './i18n/index.js';
const route = useRoute();
const menuOpen = ref(false);
async function closeMenu() { menuOpen.value = false; await nextTick(); document.getElementById('menu-toggle')?.focus(); }
watch(() => route.path, async () => { await nextTick(); document.getElementById('main-content')?.focus(); });
const landingUrl = import.meta.env.VITE_LANDING_URL || 'http://localhost:5173/creditor-landing-page/';
const logoUrl = `${import.meta.env.BASE_URL}favicon.svg`;
const links = [ ['dashboard', 'pi-chart-bar'], ['purchases', 'pi-receipt'], ['suppliers', 'pi-building'] ];
watch([locale, () => route.path], () => {
  document.documentElement.lang = locale.value;
  document.title = `${t(route.meta.title || 'nav.dashboard')} · CREDITOR`;
  menuOpen.value = false;
}, { immediate: true });
</script>

<template>
  <a class="skip-link" href="#main-content">{{ t('common.skip') }}</a>
  <div class="app-layout">
    <aside id="workspace-navigation" class="sidebar" @keydown.esc="closeMenu" :class="{ 'is-open': menuOpen }">
      <RouterLink class="brand" to="/dashboard" aria-label="CREDITOR"><img :src="logoUrl" alt="" /><span>CREDITOR<span class="brand-sub">{{ t('dashboard.eyebrow') }}</span></span></RouterLink>
      <div class="workspace"><span class="workspace-icon">MS</span><div><strong>{{ t('common.business') }}</strong><small>{{ t('common.businessType') }}</small></div><span class="workspace-dot" aria-hidden="true"></span></div>
      <nav :aria-label="t('nav.menu')"><RouterLink v-for="[key, icon] in links" :key="key" :to="`/${key}`" class="nav-link"><i class="pi" :class="icon" aria-hidden="true"></i>{{ t(`nav.${key}`) }}</RouterLink></nav>
      <div class="sidebar-bottom"><span class="demo-pill"><span aria-hidden="true"></span>{{ t('common.demo') }}</span><p>{{ t('common.demoNotice') }}</p><a :href="landingUrl" class="about-link">{{ t('nav.landing') }}<i class="pi pi-arrow-up-right" aria-hidden="true"></i></a></div>
    </aside>
    <div v-if="menuOpen" class="sidebar-backdrop" @click="closeMenu" aria-hidden="true"></div>
    <div class="content-shell">
      <header class="topbar"><Button id="menu-toggle" aria-controls="workspace-navigation" class="menu-toggle" icon="pi pi-bars" :aria-label="t('nav.menu')" :aria-expanded="menuOpen" @click="menuOpen = !menuOpen" text /><div class="breadcrumb"><span>CREDITOR</span><span aria-hidden="true">/</span><strong>{{ t(route.meta.title || 'nav.dashboard') }}</strong></div><div class="topbar-right"><label for="language" class="sr-only">{{ t('nav.language') }}</label><i class="pi pi-globe" aria-hidden="true"></i><select id="language" :value="locale" @change="setLocale($event.target.value)"><option value="en-US">English</option><option value="es-419">Español</option></select><span class="avatar" :aria-label="t('common.demo')">MS</span></div></header>
      <main id="main-content" tabindex="-1"><WorkspaceStatus /><RouterView /></main>
      <footer class="app-footer"><span>© 2026 CREDITOR · {{ t('common.demo') }}</span><div><RouterLink to="/terms">{{ t('legal.terms') }}</RouterLink><RouterLink to="/privacy">{{ t('legal.privacy') }}</RouterLink></div></footer>
    </div>
  </div>
</template>
