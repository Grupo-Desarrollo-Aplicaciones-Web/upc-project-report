<script setup>import { t } from '../i18n/index.js'; defineProps({ status: String });</script>
<template><span class="status-badge" :class="status"><span aria-hidden="true"></span>{{ t(`purchase.${status}`) }}</span></template>
