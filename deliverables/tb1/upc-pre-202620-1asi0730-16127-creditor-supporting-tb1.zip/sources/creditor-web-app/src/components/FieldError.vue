<script setup>import { t } from '../i18n/index.js'; defineProps({ error: String, id: String });</script>
<template><small v-if="error" :id="id" class="field-error">{{ t(error) }}</small></template>
