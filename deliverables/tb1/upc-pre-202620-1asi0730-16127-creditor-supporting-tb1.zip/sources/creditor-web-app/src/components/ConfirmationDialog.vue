<script setup>
import Dialog from 'primevue/dialog';
import Button from 'primevue/button';
import { t } from '../i18n/index.js';
defineProps({ visible: Boolean, title: String, confirmLabel: String, busy: Boolean, error: String });
defineEmits(['update:visible', 'confirm']);
</script>
<template><Dialog :visible="visible" @update:visible="$emit('update:visible', $event)" :header="title" modal :style="{ width: '460px', maxWidth: 'calc(100vw - 32px)' }" :closable="!busy" :closeOnEscape="!busy" :dismissableMask="false"><slot /><p v-if="error" class="error-message" role="alert">{{ t(error) }}</p><template #footer><Button :label="t('common.cancel')" severity="secondary" outlined :disabled="busy" @click="$emit('update:visible', false)" /><Button :label="confirmLabel || t('common.confirm')" :loading="busy" :disabled="busy" @click="$emit('confirm')" /></template></Dialog></template>
