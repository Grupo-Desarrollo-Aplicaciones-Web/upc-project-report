<script setup>
import { ref } from 'vue';
import Button from 'primevue/button';
import { useWorkspace } from '../stores/workspace.js';
import { t } from '../i18n/index.js';
import ConfirmationDialog from './ConfirmationDialog.vue';
const { state, reload, reset, clearNotice } = useWorkspace();
const confirmReset = ref(false);
const resetError = ref(null);
function restore() { try { reset(); confirmReset.value = false; resetError.value = null; } catch (error) { resetError.value = error.key || 'common.storageError'; } }
</script>
<template>
  <p v-if="state.loading" class="workspace-loading" role="status">{{ t('common.loading') }}</p>
  <div v-if="state.error" class="global-alert error-alert" role="alert"><i class="pi pi-exclamation-triangle" aria-hidden="true"></i><div><strong>{{ t('common.errorHeading') }}</strong><p>{{ t(state.error) }}</p><div class="alert-actions"><Button :label="t('common.retry')" size="small" @click="reload" outlined /><Button :label="t('common.reset')" size="small" severity="secondary" @click="confirmReset = true" /></div></div></div>
  <div v-if="state.notice" class="global-alert success-alert" role="status"><i class="pi pi-check-circle" aria-hidden="true"></i><strong>{{ t(state.notice) }}</strong><Button :aria-label="t('common.close')" icon="pi pi-times" text rounded @click="clearNotice" /></div>
  <ConfirmationDialog v-model:visible="confirmReset" :title="t('common.resetTitle')" :confirmLabel="t('common.resetConfirm')" :error="resetError" @confirm="restore"><p class="dialog-description">{{ t('common.resetBody') }}</p></ConfirmationDialog>
</template>
