<script setup>defineProps({ title: String, description: String, icon: { type: String, default: 'pi-inbox' } });</script>
<template><div class="empty-state"><i class="pi empty-icon" :class="icon" aria-hidden="true"></i><h2>{{ title }}</h2><p>{{ description }}</p><slot /></div></template>
