<script setup>
import { reactive, ref, computed, nextTick } from 'vue';
import InputText from 'primevue/inputtext';
import Textarea from 'primevue/textarea';
import Button from 'primevue/button';
import { useWorkspace } from '../stores/workspace.js';
import { validatePayment } from '../domain/payments.js';
import { balanceCents, parseAmount } from '../domain/money.js';
import { today } from '../domain/dates.js';
import { validateFile, readVoucher } from '../domain/attachments.js';
import { DEMO_ORGANIZATION_ID } from '../data/seed.js';
import { t, formatMoney, formatDate } from '../i18n/index.js';
import FieldError from './FieldError.vue';
import ConfirmationDialog from './ConfirmationDialog.vue';
const props = defineProps({ purchase: Object });
const emit = defineEmits(['saved']);
const { state, addPayment } = useWorkspace();
const form = reactive({ amount: '', paidOn: today(), note: '' });
const errors = ref({}); const file = ref(null); const busy = ref(false); const reviewing = ref(false); const pending = ref(null); const saveError = ref(null);
const balance = computed(() => balanceCents(props.purchase, state.payments));
const cents = computed(() => parseAmount(form.amount) || 0);
async function focusError() { await nextTick(); document.getElementById(`payment-${Object.keys(errors.value)[0]}`)?.focus(); }
async function review() {
  errors.value = validatePayment({ ...form, currency: props.purchase.currency }, props.purchase, state.payments, DEMO_ORGANIZATION_ID);
  const fileError = validateFile(file.value); if (fileError) errors.value.voucher = fileError;
  saveError.value = null;
  if (Object.keys(errors.value).length) { await focusError(); return; }
  busy.value = true;
  try { pending.value = { ...form, currency: props.purchase.currency, voucher: await readVoucher(file.value) }; reviewing.value = true; }
  catch (error) { errors.value.voucher = error.message; await focusError(); }
  finally { busy.value = false; }
}
async function save() {
  if (busy.value) return; busy.value = true; saveError.value = null;
  try { const payment = await addPayment(props.purchase.id, pending.value); reviewing.value = false; emit('saved', payment); }
  catch (error) { errors.value = error.fields || {}; saveError.value = error.key || 'common.storageError'; }
  finally { busy.value = false; }
}
</script>
<template><form class="surface entry-form payment-entry" @submit.prevent="review" novalidate><h2>{{ t('payment.formTitle') }}</h2><div class="payment-current"><span>{{ t('purchase.remaining') }}</span><strong>{{ formatMoney(balance, purchase.currency) }}</strong></div><p class="currency-note">{{ t('payment.currencyHint', { currency: purchase.currency }) }}</p><p v-if="Object.keys(errors).length" class="validation-summary" role="alert">{{ t('common.validationSummary') }}</p><div class="form-grid"><div class="field"><label for="payment-amount">{{ t('payment.amount') }} ({{ purchase.currency }}) <span class="required-mark" aria-hidden="true">*</span></label><InputText id="payment-amount" v-model="form.amount" inputmode="decimal" placeholder="0.00" maxlength="11" required :aria-invalid="!!errors.amount" :aria-describedby="errors.amount ? 'payment-amount-error' : undefined" /><FieldError id="payment-amount-error" :error="errors.amount" /></div><div class="field"><label for="payment-paidOn">{{ t('payment.date') }} <span class="required-mark" aria-hidden="true">*</span></label><input id="payment-paidOn" v-model="form.paidOn" type="date" :min="purchase.purchasedOn" :max="today()" required :aria-invalid="!!errors.paidOn" :aria-describedby="errors.paidOn ? 'payment-paidOn-error' : undefined" /><FieldError id="payment-paidOn-error" :error="errors.paidOn" /></div><div class="field span-two"><label for="payment-note">{{ t('payment.note') }} <span class="optional-mark">({{ t('common.optional') }})</span></label><Textarea id="payment-note" v-model="form.note" rows="3" maxlength="200" :aria-invalid="!!errors.note" :aria-describedby="errors.note ? 'payment-note-error' : undefined" /><FieldError id="payment-note-error" :error="errors.note" /></div><div class="field span-two"><label for="payment-voucher">{{ t('payment.voucher') }} <span class="optional-mark">({{ t('common.optional') }})</span></label><input id="payment-voucher" type="file" accept="application/pdf,image/png,image/jpeg" @change="file = $event.target.files?.[0] || null" :aria-invalid="!!errors.voucher" :aria-describedby="`payment-voucher-hint${errors.voucher ? ' payment-voucher-error' : ''}`" /><small id="payment-voucher-hint">{{ t('common.attachmentHint') }}</small><FieldError id="payment-voucher-error" :error="errors.voucher" /></div></div><div class="form-actions"><RouterLink :to="`/purchases/${purchase.id}`" class="cancel-link">{{ t('common.cancel') }}</RouterLink><Button type="submit" :label="t('payment.review')" icon="pi pi-arrow-right" iconPos="right" :loading="busy" :disabled="busy || balance <= 0" /></div><p v-if="balance === 0" class="settled-message" role="status"><i class="pi pi-check-circle" aria-hidden="true"></i>{{ t('payment.settledHint') }}</p>
  <ConfirmationDialog v-model:visible="reviewing" :title="t('payment.review')" :confirmLabel="t('payment.confirm')" :busy="busy" :error="saveError" @confirm="save"><p class="dialog-description">{{ t('payment.reviewHint') }}</p><dl class="review-list"><div><dt>{{ t('common.reference') }}</dt><dd>{{ purchase.reference }}</dd></div><div><dt>{{ t('payment.amount') }}</dt><dd>{{ formatMoney(cents, purchase.currency) }}</dd></div><div><dt>{{ t('payment.date') }}</dt><dd>{{ form.paidOn ? formatDate(form.paidOn) : '—' }}</dd></div><div class="balance-after"><dt>{{ t('payment.balanceAfter') }}</dt><dd>{{ formatMoney(balance - cents, purchase.currency) }}</dd></div></dl></ConfirmationDialog>
</form></template>
