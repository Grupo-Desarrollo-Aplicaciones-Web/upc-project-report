<script setup>
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useWorkspace } from '../stores/workspace.js';
import { t, formatMoney } from '../i18n/index.js';
import { balanceCents } from '../domain/money.js';
import PaymentForm from '../components/PaymentForm.vue';
import EmptyState from '../components/EmptyState.vue';
const route = useRoute(); const router = useRouter(); const { state } = useWorkspace();
const purchase = computed(() => state.purchases.find(item => item.id === route.params.id));
const supplier = computed(() => state.suppliers.find(item => item.id === purchase.value?.supplierId));
function saved() { router.push(`/purchases/${purchase.value.id}`); }
</script>
<template><section class="page"><template v-if="purchase && !state.error"><RouterLink :to="`/purchases/${purchase.id}`" class="back-link"><i class="pi pi-arrow-left" aria-hidden="true"></i>{{ purchase.reference }}</RouterLink><div class="page-header"><div><span class="eyebrow">{{ t('dashboard.eyebrow') }}</span><h1>{{ t('payment.new') }}</h1><p class="page-subtitle">{{ supplier?.name }} · {{ purchase.reference }}</p></div></div><div class="form-layout"><PaymentForm :key="purchase.id" :purchase="purchase" @saved="saved" /><aside class="form-aside"><article class="surface form-preview"><span class="eyebrow">{{ t('purchase.overview') }}</span><div class="preview-icon"><i class="pi pi-wallet" aria-hidden="true"></i></div><h2>{{ supplier?.name }}</h2><strong class="preview-amount">{{ formatMoney(balanceCents(purchase, state.payments), purchase.currency) }}</strong><span class="currency-chip">{{ purchase.currency }}</span><p>{{ t('purchase.remainingHint') }}</p></article><div class="local-reminder"><i class="pi pi-lock" aria-hidden="true"></i><p>{{ t('common.demoNotice') }}</p></div></aside></div></template><EmptyState v-else-if="!state.error" :title="t('purchase.notFound')" :description="t('purchase.notFoundHint')" icon="pi-search"><RouterLink to="/purchases" class="primary-link">{{ t('purchase.title') }}</RouterLink></EmptyState></section></template>
