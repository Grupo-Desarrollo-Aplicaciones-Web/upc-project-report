<script setup>import { t } from '../i18n/index.js';</script>
<template><section class="page empty-state"><i class="pi pi-compass empty-icon" aria-hidden="true"></i><h1>{{ t('common.notFound') }}</h1><p>{{ t('common.notFoundBody') }}</p><RouterLink to="/dashboard" class="primary-link">{{ t('common.goHome') }}</RouterLink></section></template>
