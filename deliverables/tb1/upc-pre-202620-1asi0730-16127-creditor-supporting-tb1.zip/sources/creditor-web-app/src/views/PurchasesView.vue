<script setup>
import { reactive, computed, watch } from 'vue';
import { useRoute } from 'vue-router';
import InputText from 'primevue/inputtext';
import Button from 'primevue/button';
import { useWorkspace } from '../stores/workspace.js';
import { filterPurchases } from '../domain/purchases.js';
import { t } from '../i18n/index.js';
import PurchaseTable from '../components/PurchaseTable.vue';
import EmptyState from '../components/EmptyState.vue';
const { state } = useWorkspace();
const route = useRoute();
const filters = reactive({ query: '', supplierId: '', currency: '', status: '', dueFrom: '', dueTo: '' });
watch(() => route.query.status, value => { filters.status = ['pending', 'overdue', 'settled', 'dueSoon'].includes(value) ? value : ''; }, { immediate: true });
watch(() => route.query.supplier, value => { filters.supplierId = state.suppliers.some(item => item.id === value) ? value : ''; }, { immediate: true });
const purchases = computed(() => filterPurchases(state.purchases, state.suppliers, state.payments, filters));
function clear() { Object.keys(filters).forEach(key => { filters[key] = ''; }); }
</script>
<template><section class="page"><div class="page-header"><div><span class="eyebrow">{{ t('dashboard.eyebrow') }}</span><h1>{{ t('purchase.title') }}</h1><p class="page-subtitle">{{ t('purchase.subtitle') }}</p></div><RouterLink to="/purchases/new" class="primary-link"><i class="pi pi-plus" aria-hidden="true"></i>{{ t('dashboard.newPurchase') }}</RouterLink></div>
  <template v-if="!state.error"><div class="surface filters-panel"><div class="search-field"><label for="purchase-search">{{ t('common.search') }}</label><div class="search-input"><i class="pi pi-search" aria-hidden="true"></i><InputText id="purchase-search" v-model="filters.query" :placeholder="t('purchase.search')" /></div></div><div class="filter-row"><div class="field"><label for="filter-supplier">{{ t('purchase.supplier') }}</label><select id="filter-supplier" v-model="filters.supplierId"><option value="">{{ t('purchase.allSuppliers') }}</option><option v-for="supplier in state.suppliers" :key="supplier.id" :value="supplier.id">{{ supplier.name }}</option></select></div><div class="field"><label for="filter-currency">{{ t('common.currency') }}</label><select id="filter-currency" v-model="filters.currency"><option value="">{{ t('purchase.allCurrencies') }}</option><option>PEN</option><option>USD</option></select></div><div class="field"><label for="filter-status">{{ t('common.status') }}</label><select id="filter-status" v-model="filters.status"><option value="">{{ t('purchase.allStatuses') }}</option><option v-for="status in ['pending', 'overdue', 'dueSoon', 'settled']" :key="status" :value="status">{{ t(`purchase.${status}`) }}</option></select></div><div class="field"><label for="filter-from">{{ t('purchase.fromDue') }}</label><input id="filter-from" v-model="filters.dueFrom" type="date" /></div><div class="field"><label for="filter-to">{{ t('purchase.toDue') }}</label><input id="filter-to" v-model="filters.dueTo" type="date" :min="filters.dueFrom || undefined" /></div></div></div>
  <div class="results-heading"><span role="status">{{ t('purchase.filterCount', { count: purchases.length }) }}</span><Button :label="t('common.clearFilters')" text size="small" icon="pi pi-filter-slash" @click="clear" /></div><article class="surface"><PurchaseTable v-if="purchases.length" :purchases="purchases" :suppliers="state.suppliers" :payments="state.payments" :caption="t('purchase.title')" /><EmptyState v-else :title="t(state.purchases.length ? 'common.noResults' : 'common.noData')" :description="t('purchase.emptyHint')"><Button v-if="state.purchases.length" :label="t('common.clearFilters')" @click="clear" outlined /><RouterLink v-else to="/purchases/new" class="primary-link">{{ t('dashboard.newPurchase') }}</RouterLink></EmptyState></article></template>
</section></template>
