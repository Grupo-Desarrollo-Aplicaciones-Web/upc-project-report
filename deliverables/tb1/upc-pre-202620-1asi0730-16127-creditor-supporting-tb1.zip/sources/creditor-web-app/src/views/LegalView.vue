<script setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import { t } from '../i18n/index.js';
const route = useRoute();
const privacy = computed(() => route.path === '/privacy');
</script>
<template><section class="page legal-page"><span class="eyebrow">CREDITOR</span><h1>{{ t(privacy ? 'legal.privacy' : 'legal.terms') }}</h1><p class="page-subtitle">{{ t('legal.updated') }}</p><article class="surface prose"><h2>{{ t('legal.usage') }}</h2><p>{{ t(privacy ? 'legal.privacyBody' : 'legal.termsBody') }}</p><p>{{ t('legal.source') }}</p></article></section></template>
