<script setup>
import { reactive, ref, computed, nextTick } from 'vue';
import { useRouter } from 'vue-router';
import InputText from 'primevue/inputtext';
import Textarea from 'primevue/textarea';
import Button from 'primevue/button';
import { useWorkspace } from '../stores/workspace.js';
import { validatePurchase } from '../domain/purchases.js';
import { parseAmount } from '../domain/money.js';
import { readVoucher, validateFile } from '../domain/attachments.js';
import { today, shiftDate } from '../domain/dates.js';
import { DEMO_ORGANIZATION_ID } from '../data/seed.js';
import { t, formatMoney, formatDate } from '../i18n/index.js';
import FieldError from '../components/FieldError.vue';
import ConfirmationDialog from '../components/ConfirmationDialog.vue';
const router = useRouter();
const { state, addPurchase } = useWorkspace();
const form = reactive({ supplierId: '', reference: '', description: '', currency: 'PEN', amount: '', purchasedOn: today(), dueOn: shiftDate(today(), 30) });
const errors = ref({}); const file = ref(null); const reviewing = ref(false); const busy = ref(false); const saveError = ref(null); const pending = ref(null);
const supplier = computed(() => state.suppliers.find(item => item.id === form.supplierId));
const cents = computed(() => parseAmount(form.amount) || 0);
const describedBy = field => [`purchase-${field}-hint`, ...(errors.value[field] ? [`purchase-${field}-error`] : [])].join(' ');
async function focusError() { await nextTick(); document.getElementById(`purchase-${Object.keys(errors.value)[0]}`)?.focus(); }
async function review() {
  errors.value = validatePurchase(form, state.suppliers, DEMO_ORGANIZATION_ID, state.purchases);
  const fileError = validateFile(file.value); if (fileError) errors.value.voucher = fileError;
  saveError.value = null;
  if (Object.keys(errors.value).length) { await focusError(); return; }
  busy.value = true;
  try { pending.value = { ...form, voucher: await readVoucher(file.value) }; reviewing.value = true; }
  catch (error) { errors.value.voucher = error.message; await focusError(); }
  finally { busy.value = false; }
}
async function save() {
  if (busy.value) return; busy.value = true; saveError.value = null;
  try { const purchase = await addPurchase(pending.value); reviewing.value = false; router.push(`/purchases/${purchase.id}`); }
  catch (error) { errors.value = error.fields || {}; saveError.value = error.key || 'common.storageError'; }
  finally { busy.value = false; }
}
</script>
<template><section class="page"><RouterLink to="/purchases" class="back-link"><i class="pi pi-arrow-left" aria-hidden="true"></i>{{ t('purchase.title') }}</RouterLink><div class="page-header"><div><span class="eyebrow">{{ t('dashboard.eyebrow') }}</span><h1>{{ t('purchase.new') }}</h1><p class="page-subtitle">{{ t('purchase.newHint') }}</p></div></div>
  <div v-if="!state.error" class="form-layout"><form class="surface entry-form" @submit.prevent="review" novalidate><h2>{{ t('purchase.information') }}</h2><p v-if="Object.keys(errors).length" class="validation-summary" role="alert">{{ t('common.validationSummary') }}</p><div class="form-grid">
    <div class="field span-two"><label for="purchase-supplierId">{{ t('purchase.supplier') }} <span class="required-mark" aria-hidden="true">*</span></label><select id="purchase-supplierId" v-model="form.supplierId" required :aria-invalid="!!errors.supplierId" :aria-describedby="describedBy('supplierId')"><option value="">{{ t('purchase.selectSupplier') }}</option><option v-for="item in state.suppliers" :key="item.id" :value="item.id">{{ item.name }}</option></select><small id="purchase-supplierId-hint"><RouterLink to="/suppliers" class="inline-link">{{ t('supplier.new') }}</RouterLink></small><FieldError id="purchase-supplierId-error" :error="errors.supplierId" /></div>
    <div class="field"><label for="purchase-reference">{{ t('purchase.reference') }} <span class="required-mark" aria-hidden="true">*</span></label><InputText id="purchase-reference" v-model="form.reference" maxlength="80" required :aria-invalid="!!errors.reference" :aria-describedby="describedBy('reference')" /><small id="purchase-reference-hint">{{ t('purchase.referenceHint') }}</small><FieldError id="purchase-reference-error" :error="errors.reference" /></div>
    <div class="field"><label for="purchase-currency">{{ t('common.currency') }} <span class="required-mark" aria-hidden="true">*</span></label><select id="purchase-currency" v-model="form.currency" required :aria-invalid="!!errors.currency" :aria-describedby="errors.currency ? 'purchase-currency-error' : undefined"><option>PEN</option><option>USD</option></select><FieldError id="purchase-currency-error" :error="errors.currency" /></div>
    <div class="field span-two"><label for="purchase-amount">{{ t('purchase.totalAmount') }} ({{ form.currency }}) <span class="required-mark" aria-hidden="true">*</span></label><InputText id="purchase-amount" v-model="form.amount" inputmode="decimal" placeholder="0.00" maxlength="11" required :aria-invalid="!!errors.amount" :aria-describedby="errors.amount ? 'purchase-amount-error' : undefined" /><FieldError id="purchase-amount-error" :error="errors.amount" /></div>
    <div class="field"><label for="purchase-purchasedOn">{{ t('purchase.purchasedOn') }} <span class="required-mark" aria-hidden="true">*</span></label><input id="purchase-purchasedOn" v-model="form.purchasedOn" type="date" min="2000-01-01" :max="today()" required :aria-invalid="!!errors.purchasedOn" :aria-describedby="errors.purchasedOn ? 'purchase-purchasedOn-error' : undefined" /><FieldError id="purchase-purchasedOn-error" :error="errors.purchasedOn" /></div>
    <div class="field"><label for="purchase-dueOn">{{ t('common.dueDate') }} <span class="required-mark" aria-hidden="true">*</span></label><input id="purchase-dueOn" v-model="form.dueOn" type="date" :min="form.purchasedOn || '2000-01-01'" max="2100-12-31" required :aria-invalid="!!errors.dueOn" :aria-describedby="errors.dueOn ? 'purchase-dueOn-error' : undefined" /><FieldError id="purchase-dueOn-error" :error="errors.dueOn" /></div>
    <div class="field span-two"><label for="purchase-description">{{ t('common.description') }} <span class="required-mark" aria-hidden="true">*</span></label><Textarea id="purchase-description" v-model="form.description" rows="3" maxlength="200" required :aria-invalid="!!errors.description" :aria-describedby="describedBy('description')" /><small id="purchase-description-hint">{{ t('purchase.descriptionHint') }}</small><FieldError id="purchase-description-error" :error="errors.description" /></div>
    <div class="field span-two"><label for="purchase-voucher">{{ t('common.file') }} <span class="optional-mark">({{ t('common.optional') }})</span></label><input id="purchase-voucher" type="file" accept="application/pdf,image/png,image/jpeg" @change="file = $event.target.files?.[0] || null" :aria-invalid="!!errors.voucher" :aria-describedby="describedBy('voucher')" /><small id="purchase-voucher-hint">{{ t('common.attachmentHint') }}</small><FieldError id="purchase-voucher-error" :error="errors.voucher" /></div>
  </div><div class="form-actions"><RouterLink to="/purchases" class="cancel-link">{{ t('common.cancel') }}</RouterLink><Button type="submit" :label="t('purchase.save')" icon="pi pi-arrow-right" iconPos="right" :loading="busy" :disabled="busy" /></div></form>
  <aside class="form-aside"><article class="surface form-preview"><span class="eyebrow">{{ t('purchase.overview') }}</span><div class="preview-icon"><i class="pi pi-receipt" aria-hidden="true"></i></div><h2>{{ supplier?.name || t('purchase.selectSupplier') }}</h2><strong class="preview-amount">{{ formatMoney(cents, form.currency) }}</strong><span class="currency-chip">{{ form.currency }}</span><dl><div><dt>{{ t('common.dueDate') }}</dt><dd>{{ form.dueOn ? formatDate(form.dueOn) : '—' }}</dd></div><div><dt>{{ t('common.reference') }}</dt><dd>{{ form.reference || '—' }}</dd></div></dl><p>{{ t('purchase.remainingHint') }}</p></article><div class="local-reminder"><i class="pi pi-lock" aria-hidden="true"></i><p>{{ t('common.demoNotice') }}</p></div></aside></div>
  <ConfirmationDialog v-model:visible="reviewing" :title="t('purchase.review')" :confirmLabel="t('purchase.confirmSave')" :busy="busy" :error="saveError" @confirm="save"><p class="dialog-description">{{ t('purchase.confirmationHint') }}</p><dl class="review-list"><div><dt>{{ t('purchase.supplier') }}</dt><dd>{{ supplier?.name }}</dd></div><div><dt>{{ t('common.reference') }}</dt><dd>{{ form.reference }}</dd></div><div><dt>{{ t('common.amount') }}</dt><dd>{{ formatMoney(cents, form.currency) }} · {{ form.currency }}</dd></div><div><dt>{{ t('common.dueDate') }}</dt><dd>{{ form.dueOn ? formatDate(form.dueOn) : '—' }}</dd></div></dl></ConfirmationDialog>
</section></template>
