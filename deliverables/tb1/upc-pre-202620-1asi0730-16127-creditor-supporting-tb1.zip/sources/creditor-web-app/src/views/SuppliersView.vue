<script setup>
import { computed, reactive, ref, nextTick } from 'vue';
import Button from 'primevue/button';
import InputText from 'primevue/inputtext';
import Dialog from 'primevue/dialog';
import { useWorkspace } from '../stores/workspace.js';
import { validateSupplier } from '../domain/purchases.js';
import { summarizeByCurrency } from '../domain/money.js';
import { t, formatMoney } from '../i18n/index.js';
import FieldError from '../components/FieldError.vue';
import EmptyState from '../components/EmptyState.vue';
const { state, addSupplier } = useWorkspace();
const query = ref(''); const showForm = ref(false); const busy = ref(false); const errors = ref({}); const saveError = ref(null);
const form = reactive({ name: '', email: '', taxId: '', phone: '' });
const filtered = computed(() => state.suppliers.filter(item => `${item.name} ${item.taxId}`.toLowerCase().includes(query.value.toLowerCase())));
function summary(supplierId) { return summarizeByCurrency(state.purchases.filter(item => item.supplierId === supplierId), state.payments); }
async function save() {
  errors.value = validateSupplier(form); saveError.value = null;
  if (Object.keys(errors.value).length) { await nextTick(); document.getElementById(`supplier-${Object.keys(errors.value)[0]}`)?.focus(); return; }
  busy.value = true;
  try { await addSupplier(form); showForm.value = false; Object.keys(form).forEach(key => { form[key] = ''; }); }
  catch (error) { errors.value = error.fields || {}; saveError.value = error.key || 'common.storageError'; }
  finally { busy.value = false; }
}
</script>
<template><section class="page"><div class="page-header"><div><span class="eyebrow">{{ t('dashboard.eyebrow') }}</span><h1>{{ t('supplier.title') }}</h1><p class="page-subtitle">{{ t('supplier.subtitle') }}</p></div><Button :label="t('supplier.new')" icon="pi pi-plus" @click="showForm = true" /></div><template v-if="!state.error"><div class="supplier-search search-input"><label for="supplier-search" class="sr-only">{{ t('supplier.search') }}</label><i class="pi pi-search" aria-hidden="true"></i><InputText id="supplier-search" v-model="query" :placeholder="t('supplier.search')" /></div><div v-if="filtered.length" class="supplier-grid"><article v-for="supplier in filtered" :key="supplier.id" class="surface supplier-card"><div class="supplier-card-heading"><span class="supplier-avatar large" aria-hidden="true">{{ supplier.name.slice(0, 2).toUpperCase() }}</span><div><h2>{{ supplier.name }}</h2><small>{{ supplier.taxId || '—' }}</small></div></div><div class="supplier-contact"><span v-if="supplier.email"><i class="pi pi-envelope" aria-hidden="true"></i>{{ supplier.email }}</span><span v-if="supplier.phone"><i class="pi pi-phone" aria-hidden="true"></i>{{ supplier.phone }}</span></div><div class="supplier-balances"><div v-for="item in summary(supplier.id)" :key="item.currency"><span>{{ item.currency }} · {{ t('supplier.outstanding') }}</span><strong>{{ formatMoney(item.balanceCents, item.currency) }}</strong></div></div><RouterLink :to="{ path: '/purchases', query: { supplier: supplier.id } }" class="supplier-view" @click="null"><span>{{ t('supplier.count', { count: state.purchases.filter(item => item.supplierId === supplier.id).length }) }}</span><span>{{ t('dashboard.allPurchases') }}<i class="pi pi-arrow-right" aria-hidden="true"></i></span></RouterLink></article></div><EmptyState v-else :title="t(query ? 'common.noResults' : 'supplier.empty')" :description="t('supplier.emptyHint')" icon="pi-building"><Button :label="query ? t('common.clearFilters') : t('supplier.new')" @click="query ? query = '' : showForm = true" /></EmptyState></template>
  <Dialog v-model:visible="showForm" :header="t('supplier.review')" modal :closable="!busy" :style="{ width: '480px', maxWidth: 'calc(100vw - 32px)' }"><form @submit.prevent="save" novalidate><p v-if="Object.keys(errors).length" role="alert" class="validation-summary">{{ t('common.validationSummary') }}</p><p v-if="saveError" role="alert" class="error-message">{{ t(saveError) }}</p><div class="supplier-form"><div class="field"><label for="supplier-name">{{ t('supplier.name') }} <span class="required-mark" aria-hidden="true">*</span></label><InputText id="supplier-name" v-model="form.name" maxlength="100" :placeholder="t('supplier.nameHint')" required :aria-invalid="!!errors.name" :aria-describedby="errors.name ? 'supplier-name-error' : undefined" /><FieldError id="supplier-name-error" :error="errors.name" /></div><div v-for="field in ['taxId', 'email', 'phone']" :key="field" class="field"><label :for="`supplier-${field}`">{{ t(field === 'email' ? 'supplier.contact' : `supplier.${field}`) }} <span class="optional-mark">({{ t('common.optional') }})</span></label><InputText :id="`supplier-${field}`" v-model="form[field]" :type="field === 'email' ? 'email' : 'text'" :maxlength="field === 'email' ? 150 : 30" :aria-invalid="!!errors[field]" :aria-describedby="errors[field] ? `supplier-${field}-error` : undefined" /><FieldError :id="`supplier-${field}-error`" :error="errors[field]" /></div></div><div class="form-actions"><Button :label="t('common.cancel')" severity="secondary" outlined :disabled="busy" @click="showForm = false" /><Button type="submit" :label="t('supplier.save')" :loading="busy" :disabled="busy" /></div></form></Dialog>
</section></template>
