<script setup>
import { computed, ref } from 'vue';
import Button from 'primevue/button';
import { useWorkspace } from '../stores/workspace.js';
import { t, formatMoney, formatDate } from '../i18n/index.js';
import { balanceCents, summarizeByCurrency } from '../domain/money.js';
import { dayDifference, today } from '../domain/dates.js';
import PurchaseTable from '../components/PurchaseTable.vue';
import EmptyState from '../components/EmptyState.vue';
import ConfirmationDialog from '../components/ConfirmationDialog.vue';
const { state, reset } = useWorkspace();
const confirmReset = ref(false);
const resetError = ref(null);
const summaries = computed(() => summarizeByCurrency(state.purchases, state.payments));
const outstanding = computed(() => state.purchases.filter(purchase => balanceCents(purchase, state.payments) > 0));
const upcoming = computed(() => [...outstanding.value].sort((a, b) => a.dueOn.localeCompare(b.dueOn)).slice(0, 5));
const overdue = computed(() => outstanding.value.filter(purchase => dayDifference(purchase.dueOn) < 0));
const dueSoon = computed(() => outstanding.value.filter(purchase => { const days = dayDifference(purchase.dueOn); return days >= 0 && days <= 7; }));
const paidCount = computed(() => state.purchases.length - outstanding.value.length);
function restore() { try { reset(); confirmReset.value = false; resetError.value = null; } catch (error) { resetError.value = error.key || 'common.storageError'; } }
</script>
<template><section class="page dashboard-page">
  <div class="page-header"><div><span class="eyebrow">{{ t('dashboard.eyebrow') }}</span><h1>{{ t('dashboard.title') }}</h1><p class="page-subtitle">{{ t('dashboard.subtitle') }}</p></div><RouterLink to="/purchases/new" class="primary-link"><i class="pi pi-plus" aria-hidden="true"></i>{{ t('dashboard.newPurchase') }}</RouterLink></div>
  <template v-if="!state.error">
    <div class="section-meta"><span>{{ t('dashboard.currencies') }}</span><span><i class="pi pi-calendar" aria-hidden="true"></i>{{ formatDate(today()) }}</span></div>
    <div class="balance-grid"><article v-for="summary in summaries" :key="summary.currency" class="surface balance-card" :class="{ 'primary-balance': summary.currency === 'PEN' }"><div class="balance-card-top"><span>{{ t('dashboard.outstanding') }}</span><span class="currency-chip">{{ summary.currency }}</span></div><strong class="balance-value" :data-testid="`balance-${summary.currency}`">{{ formatMoney(summary.balanceCents, summary.currency) }}</strong><div class="balance-card-foot"><span>{{ summary.count }} {{ t('dashboard.open') }}</span><span><i class="pi pi-wallet" aria-hidden="true"></i>{{ t('dashboard.paidToDate') }}: {{ formatMoney(summary.paidCents, summary.currency) }}</span></div></article></div>
    <p class="currency-note"><i class="pi pi-info-circle" aria-hidden="true"></i>{{ t('dashboard.currencyHint') }}</p>
    <div class="metric-grid"><article class="surface metric-card"><div class="metric-icon indigo"><i class="pi pi-receipt" aria-hidden="true"></i></div><div><span>{{ t('dashboard.openPurchases') }}</span><strong>{{ outstanding.length }}</strong></div></article><article class="surface metric-card"><div class="metric-icon rose"><i class="pi pi-clock" aria-hidden="true"></i></div><div><span>{{ t('dashboard.overdue') }}</span><strong>{{ overdue.length }}</strong></div></article><article class="surface metric-card"><div class="metric-icon amber"><i class="pi pi-calendar" aria-hidden="true"></i></div><div><span>{{ t('dashboard.dueSoon') }}</span><strong>{{ dueSoon.length }}</strong></div></article><article class="surface metric-card"><div class="metric-icon teal"><i class="pi pi-building" aria-hidden="true"></i></div><div><span>{{ t('dashboard.suppliers') }}</span><strong>{{ state.suppliers.length }}</strong></div></article></div>
    <div class="dashboard-bottom"><article class="surface upcoming-card"><div class="section-heading"><div><h2>{{ t('dashboard.upcoming') }}</h2><p>{{ t('dashboard.upcomingHint') }}</p></div><RouterLink to="/purchases" class="secondary-link">{{ t('dashboard.allPurchases') }}<i class="pi pi-arrow-right" aria-hidden="true"></i></RouterLink></div><PurchaseTable v-if="upcoming.length" :purchases="upcoming" :suppliers="state.suppliers" :payments="state.payments" :caption="t('dashboard.upcoming')" /><EmptyState v-else :title="t(state.purchases.length ? 'dashboard.settled' : 'dashboard.emptyTitle')" :description="t(state.purchases.length ? 'dashboard.settledBody' : 'dashboard.emptyBody')"><RouterLink v-if="!state.purchases.length" to="/purchases/new" class="primary-link">{{ t('dashboard.newPurchase') }}</RouterLink></EmptyState></article><article class="surface health-card"><span class="eyebrow">{{ t('dashboard.businessHealth') }}</span><h2>{{ t('dashboard.attention') }}</h2><div class="health-number"><strong>{{ overdue.length }}</strong><span>{{ t('dashboard.overdue') }}</span></div><p>{{ t('dashboard.businessHint') }}</p><div class="health-bar" aria-hidden="true"><span :style="{ width: `${state.purchases.length ? paidCount / state.purchases.length * 100 : 0}%` }"></span></div><div class="health-legend"><span><i class="legend-dot teal" aria-hidden="true"></i>{{ t('purchase.settled') }} <strong>{{ paidCount }}</strong></span><span><i class="legend-dot indigo" aria-hidden="true"></i>{{ t('purchase.pending') }} <strong>{{ outstanding.length }}</strong></span></div><RouterLink to="/purchases?status=overdue" class="secondary-link">{{ t('purchase.overdueOnly') }}<i class="pi pi-arrow-right" aria-hidden="true"></i></RouterLink></article></div>
  </template>
  <div class="demo-tools"><span><i class="pi pi-desktop" aria-hidden="true"></i>{{ t('common.demo') }}</span><Button :label="t('common.reset')" icon="pi pi-refresh" text size="small" @click="confirmReset = true" /></div>
  <ConfirmationDialog v-model:visible="confirmReset" :title="t('common.resetTitle')" :confirmLabel="t('common.resetConfirm')" :error="resetError" @confirm="restore"><p class="dialog-description">{{ t('common.resetBody') }}</p></ConfirmationDialog>
</section></template>
