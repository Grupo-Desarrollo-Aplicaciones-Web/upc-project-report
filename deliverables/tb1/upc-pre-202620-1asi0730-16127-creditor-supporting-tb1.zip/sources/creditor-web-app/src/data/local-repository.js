import { createSeed, DEMO_ORGANIZATION_ID } from './seed.js';
import { validatePurchase, validateSupplier } from '../domain/purchases.js';
import { parseAmount, balanceCents, MAX_AMOUNT_CENTS, CURRENCIES } from '../domain/money.js';
import { validDate } from '../domain/dates.js';
import { validVoucher } from '../domain/attachments.js';
import { validatePayment } from '../domain/payments.js';

export const STORAGE_KEY = 'creditor.demo.accounts-payable.v1';
export class RepositoryError extends Error {
  constructor(key, fields = {}) { super(key); this.key = key; this.fields = fields; }
}
const clone = data => structuredClone(data);
const validAmount = value => Number.isInteger(value) && value > 0 && value <= MAX_AMOUNT_CENTS;

export function validateStoredData(data) {
  if (!data || data.schemaVersion !== 1 || !Number.isInteger(data.revision) || data.revision < 0 || !['suppliers', 'purchases', 'payments'].every(key => Array.isArray(data[key]))) return false;
  const all = [...data.suppliers, ...data.purchases, ...data.payments];
  if (all.some(item => !item || typeof item.id !== 'string' || typeof item.organizationId !== 'string')) return false;
  if (new Set(all.map(item => item.id)).size !== all.length) return false;
  if (data.suppliers.some(supplier => typeof supplier.name !== 'string' || Object.keys(validateSupplier(supplier)).length)) return false;
  if (data.purchases.some(purchase => !validAmount(purchase.amountCents) || !CURRENCIES.includes(purchase.currency) || !validDate(purchase.purchasedOn) || !validDate(purchase.dueOn) || purchase.dueOn < purchase.purchasedOn || typeof purchase.reference !== 'string' || typeof purchase.description !== 'string' || !validVoucher(purchase.voucher) || !data.suppliers.some(supplier => supplier.id === purchase.supplierId && supplier.organizationId === purchase.organizationId))) return false;
  if (data.payments.some(payment => {
    const purchase = data.purchases.find(item => item.id === payment.purchaseId && item.organizationId === payment.organizationId);
    return !purchase || payment.currency !== purchase.currency || !validAmount(payment.amountCents) || !validDate(payment.paidOn) || payment.paidOn < purchase.purchasedOn || typeof payment.note !== 'string' || !validVoucher(payment.voucher);
  })) return false;
  return data.purchases.every(purchase => balanceCents(purchase, data.payments) >= 0);
}

export function createLocalRepository(storage, organizationId = DEMO_ORGANIZATION_ID, idFactory = () => crypto.randomUUID()) {
  function read() {
    let text;
    try { text = storage.getItem(STORAGE_KEY); } catch { throw new RepositoryError('common.storageError'); }
    if (text === null) {
      const seed = createSeed();
      write(seed);
      return seed;
    }
    let data;
    try { data = JSON.parse(text); } catch { throw new RepositoryError('common.corruptedStorage'); }
    if (!validateStoredData(data)) throw new RepositoryError('common.corruptedStorage');
    return data;
  }
  function write(data, expectedRevision) {
    try {
      if (expectedRevision !== undefined) {
        const current = JSON.parse(storage.getItem(STORAGE_KEY));
        if (!current || current.revision !== expectedRevision) throw new RepositoryError('common.staleData');
      }
      storage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      if (error instanceof RepositoryError) throw error;
      throw new RepositoryError('common.storageError');
    }
  }
  function scoped(data) { return { revision: data.revision, suppliers: clone(data.suppliers.filter(item => item.organizationId === organizationId)), purchases: clone(data.purchases.filter(item => item.organizationId === organizationId)), payments: clone(data.payments.filter(item => item.organizationId === organizationId)) }; }
  return {
    organizationId,
    load: () => scoped(read()),
    reset() { const data = createSeed(); write(data); return scoped(data); },
    addSupplier(input) {
      const data = read();
      const fields = validateSupplier(input);
      if (Object.keys(fields).length) throw new RepositoryError('common.validationSummary', fields);
      const record = { id: idFactory(), organizationId, name: input.name.trim(), email: (input.email || '').trim(), taxId: (input.taxId || '').trim(), phone: (input.phone || '').trim() };
      data.suppliers.push(record);
      const revision = data.revision++;
      write(data, revision);
      return clone(record);
    },
    addPurchase(input) {
      const data = read();
      const fields = validatePurchase(input, data.suppliers, organizationId, data.purchases);
      if (!validVoucher(input.voucher)) fields.voucher = 'errors.fileType';
      if (Object.keys(fields).length) throw new RepositoryError('common.validationSummary', fields);
      const record = { id: idFactory(), organizationId, supplierId: input.supplierId, reference: input.reference.trim(), description: input.description.trim(), currency: input.currency, amountCents: parseAmount(input.amount), purchasedOn: input.purchasedOn, dueOn: input.dueOn, voucher: input.voucher || null, createdAt: new Date().toISOString() };
      data.purchases.push(record);
      const revision = data.revision++;
      write(data, revision);
      return clone(record);
    },
    addPayment(purchaseId, input) {
      const data = read();
      const purchase = data.purchases.find(item => item.id === purchaseId && item.organizationId === organizationId);
      const fields = validatePayment(input, purchase, data.payments, organizationId);
      if (!validVoucher(input.voucher)) fields.voucher = 'errors.fileType';
      if (Object.keys(fields).length) throw new RepositoryError('common.validationSummary', fields);
      const record = { id: idFactory(), organizationId, purchaseId, currency: purchase.currency, amountCents: parseAmount(input.amount), paidOn: input.paidOn, note: String(input.note || '').trim(), voucher: input.voucher || null, createdAt: new Date().toISOString() };
      data.payments.push(record);
      const revision = data.revision++;
      write(data, revision);
      return clone(record);
    },
  };
}
