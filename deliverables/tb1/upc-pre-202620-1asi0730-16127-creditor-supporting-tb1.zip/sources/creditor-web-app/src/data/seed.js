import { today, shiftDate } from '../domain/dates.js';
export const DEMO_ORGANIZATION_ID = 'demo-market-sol';

export function createSeed(reference = today()) {
  const organizationId = DEMO_ORGANIZATION_ID;
  const suppliers = [
    { id: 'supplier-norte', organizationId, name: 'Distribuidora Norte', taxId: 'DEMO-001', email: 'ventas@example.com', phone: '' },
    { id: 'supplier-lima', organizationId, name: 'Empaques Lima', taxId: 'DEMO-002', email: 'contacto@example.com', phone: '' },
    { id: 'supplier-andes', organizationId, name: 'Alimentos Andinos', taxId: 'DEMO-003', email: '', phone: '' },
    { id: 'supplier-tech', organizationId, name: 'Tecno Supply', taxId: 'DEMO-004', email: '', phone: '' },
    { id: 'supplier-other', organizationId: 'other-demo-business', name: 'Other business supplier', taxId: '', email: '', phone: '' },
  ];
  const purchases = [
    { id: 'purchase-001', organizationId, supplierId: 'supplier-norte', reference: 'F001-042', description: 'Wholesale grocery inventory', currency: 'PEN', amountCents: 420000, purchasedOn: shiftDate(reference, -20), dueOn: shiftDate(reference, -3), voucher: null, createdAt: `${shiftDate(reference, -20)}T12:00:00Z` },
    { id: 'purchase-002', organizationId, supplierId: 'supplier-lima', reference: 'F004-108', description: 'Packaging materials', currency: 'PEN', amountCents: 185000, purchasedOn: shiftDate(reference, -12), dueOn: shiftDate(reference, 2), voucher: null, createdAt: `${shiftDate(reference, -12)}T12:00:00Z` },
    { id: 'purchase-003', organizationId, supplierId: 'supplier-tech', reference: 'INV-017', description: 'Point-of-sale equipment', currency: 'USD', amountCents: 132000, purchasedOn: shiftDate(reference, -8), dueOn: shiftDate(reference, 5), voucher: null, createdAt: `${shiftDate(reference, -8)}T12:00:00Z` },
    { id: 'purchase-004', organizationId, supplierId: 'supplier-andes', reference: 'F002-219', description: 'Dry goods restock', currency: 'PEN', amountCents: 295000, purchasedOn: shiftDate(reference, -5), dueOn: shiftDate(reference, 14), voucher: null, createdAt: `${shiftDate(reference, -5)}T12:00:00Z` },
    { id: 'purchase-005', organizationId, supplierId: 'supplier-norte', reference: 'F001-036', description: 'Previous grocery order', currency: 'PEN', amountCents: 160000, purchasedOn: shiftDate(reference, -35), dueOn: shiftDate(reference, -10), voucher: null, createdAt: `${shiftDate(reference, -35)}T12:00:00Z` },
  ];
  const payments = [
    { id: 'payment-001', organizationId, purchaseId: 'purchase-001', currency: 'PEN', amountCents: 120000, paidOn: shiftDate(reference, -10), note: 'First bank transfer · demo', voucher: null, createdAt: `${shiftDate(reference, -10)}T12:00:00Z` },
    { id: 'payment-002', organizationId, purchaseId: 'purchase-003', currency: 'USD', amountCents: 40000, paidOn: shiftDate(reference, -3), note: 'Equipment deposit · demo', voucher: null, createdAt: `${shiftDate(reference, -3)}T12:00:00Z` },
    { id: 'payment-003', organizationId, purchaseId: 'purchase-005', currency: 'PEN', amountCents: 160000, paidOn: shiftDate(reference, -12), note: 'Final payment · demo', voucher: null, createdAt: `${shiftDate(reference, -12)}T12:00:00Z` },
  ];
  return { schemaVersion: 1, revision: 0, suppliers, purchases, payments };
}
