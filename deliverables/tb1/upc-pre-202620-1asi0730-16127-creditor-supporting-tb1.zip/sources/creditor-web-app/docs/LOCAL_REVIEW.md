# TB1 local review

## Start

Use Node 22.12+ or 24 and the committed lockfile.

```sh
npm ci
npm run dev
```

Open `http://127.0.0.1:5174/#/dashboard`. Start the sibling landing on 5173 at `/creditor-landing-page/`. `VITE_LANDING_URL` overrides that return link; the landing uses `VITE_APP_URL` for this application. `base: './'` and hash routing prepare static hosting without a server route fallback. No hosting or publication ran.

## Verified on 03 October 2026

- 14 unit tests: positive amounts, precision, currencies, same-organization supplier, duplicate references, date/attachment boundaries, exact payments, overpayment, local storage validation and failed writes.
- 2 browser tests using Edge headless: purchase PEN 100, payment PEN 30, balance PEN 70, rejected PEN 71 with field focus and preserved input, one movement after reload, Spanish switch without currency conversion, mobile overflow check, missing purchase and privacy deep link.
- Production build passed with Vue 3.5.43, PrimeVue 4.5.5, Vite 8.3.2, Vitest 4.1.11.

Run `npm test`, `npm run test:e2e`, `npm run build`. These tests are technical evidence, not user validation or team acceptance. The report contains the integrated local screenshots and checks.

## Data contract and limitations

`src/data/local-repository.js` exposes `load`, `addSupplier`, `addPurchase`, `addPayment` and `reset`. Replace this adapter for the future ASP.NET Core service. Domain validators and integer-cent amounts stay separate from the Vue views. The fixed tenant `demo-market-sol` is fictional. Segment CTAs do not assign permissions.

Purchases require supplier, reference (2–80), description (3–200), PEN/USD, amount 0.01–9,999,999.99, purchase date no later than today and due date no earlier than purchase. Payments inherit currency and cannot exceed balance. Optional attachments accept PDF/PNG/JPEG up to 2 MB and stay in browser storage. Avoid real data: this adapter is not authentication, authorization, secure storage, a bank connection or multiuser persistence. A server must enforce tenant access, transaction atomicity and concurrent writes in AV2.

Loans and reporting export remain in Sprint 3. The new frontend has no remote repository, and `main` remains the baseline until release review.
