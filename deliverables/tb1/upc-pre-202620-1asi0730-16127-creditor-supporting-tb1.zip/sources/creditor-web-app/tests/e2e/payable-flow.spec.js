import { test, expect } from '@playwright/test';

test('purchase 100, payment 30 and rejected 71 preserve a 70 PEN balance', async ({ page }) => {
  await page.goto('/#/purchases/new');
  await page.getByRole('button', { name: 'Review purchase', exact: true }).click();
  await expect(page.locator('#purchase-supplierId')).toBeFocused();
  await expect(page.locator('#purchase-supplierId')).toHaveAttribute('aria-invalid', 'true');
  await page.locator('#purchase-supplierId').selectOption('supplier-norte');
  await page.locator('#purchase-reference').fill('TB1-E2E-100');
  await page.locator('#purchase-amount').fill('100');
  await page.locator('#purchase-description').fill('Fictional inventory for browser test');
  await page.getByRole('button', { name: 'Review purchase', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Register purchase', exact: true }).click();
  await expect(page.locator('.detail-balance-amount')).toContainText('100.00');
  const detailUrl = page.url();
  await page.getByRole('link', { name: 'Record payment', exact: true }).click();
  await page.locator('#payment-amount').fill('30');
  await page.getByRole('button', { name: 'Review payment', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Record payment', exact: true }).click();
  await expect(page.locator('.detail-balance-amount')).toContainText('70.00');
  await expect(page.locator('.payment-movement')).toHaveCount(1);
  await page.getByRole('link', { name: 'Record payment', exact: true }).click();
  await page.locator('#payment-amount').fill('71');
  await page.getByRole('button', { name: 'Review payment', exact: true }).click();
  await expect(page.locator('#payment-amount-error')).toContainText('cannot exceed');
  await expect(page.locator('#payment-amount')).toHaveValue('71');
  await expect(page.locator('#payment-amount')).toBeFocused();
  await page.goto(detailUrl);
  await page.reload();
  await expect(page.locator('.detail-balance-amount')).toContainText('70.00');
  await expect(page.locator('.payment-movement')).toHaveCount(1);
  await page.locator('#language').selectOption('es-419');
  await expect(page.locator('html')).toHaveAttribute('lang', 'es-419');
  await expect(page.locator('.detail-balance-amount')).toContainText('70.00');
  await expect(page.getByRole('link', { name: 'Registrar abono', exact: true })).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('missing purchase and legal deep links remain understandable', async ({ page }) => {
  await page.goto('/#/purchases/does-not-exist');
  await expect(page.getByRole('heading', { name: 'Purchase not found' })).toBeVisible();
  await page.goto('/#/privacy');
  await expect(page.getByRole('heading', { name: 'Privacy notice' })).toBeVisible();
});
