import { describe, it, expect } from 'vitest';
import { createLocalRepository, STORAGE_KEY, validateStoredData } from '../../src/data/local-repository.js';
import { DEMO_ORGANIZATION_ID } from '../../src/data/seed.js';
import { balanceCents } from '../../src/domain/money.js';
import { validatePayment } from '../../src/domain/payments.js';
import { validateFile, MAX_FILE_BYTES } from '../../src/domain/attachments.js';
import { memoryStorage } from './helpers.js';

const purchaseInput = { supplierId: 'supplier-norte', reference: 'TEST-100', description: 'Grocery purchase', currency: 'PEN', amount: '100', purchasedOn: '2026-01-01', dueOn: '2026-12-30', voucher: null };
const paymentInput = { amount: '30', currency: 'PEN', paidOn: '2026-02-01', note: 'Transfer', voucher: null };
function setup() { let counter = 0; const storage = memoryStorage(); const repo = createLocalRepository(storage, DEMO_ORGANIZATION_ID, () => `record-${++counter}`); const purchase = repo.addPurchase(purchaseInput); return { repo, purchase, storage }; }
describe('payment and balance business rules', () => {
  it('purchase 100 minus payment 30 has balance 70 and rejects a payment of 71', () => {
    const { repo, purchase } = setup();
    repo.addPayment(purchase.id, paymentInput);
    expect(balanceCents(purchase, repo.load().payments)).toBe(7000);
    expect(() => repo.addPayment(purchase.id, { ...paymentInput, amount: '71' })).toThrow('common.validationSummary');
    expect(repo.load().payments.filter(item => item.purchaseId === purchase.id)).toHaveLength(1);
    repo.addPayment(purchase.id, { ...paymentInput, amount: '70' });
    expect(balanceCents(purchase, repo.load().payments)).toBe(0);
    expect(() => repo.addPayment(purchase.id, { ...paymentInput, amount: '0.01' })).toThrow('common.validationSummary');
  });
  it('rereads persisted payments before validating another tab’s operation', () => {
    const { repo, purchase, storage } = setup();
    const otherTab = createLocalRepository(storage, DEMO_ORGANIZATION_ID, () => 'other-tab-payment');
    otherTab.addPayment(purchase.id, { ...paymentInput, amount: '70' });
    expect(() => repo.addPayment(purchase.id, { ...paymentInput, amount: '31' })).toThrow('common.validationSummary');
    expect(balanceCents(purchase, repo.load().payments)).toBe(3000);
  });
  it('rejects a different currency, other business, incomplete dates and dates before purchase', () => {
    const { repo, purchase } = setup();
    expect(validatePayment({ ...paymentInput, currency: 'USD' }, purchase, [], DEMO_ORGANIZATION_ID).currency).toBe('errors.currency');
    expect(validatePayment(paymentInput, { ...purchase, organizationId: 'another' }, [], DEMO_ORGANIZATION_ID).purchaseId).toBe('errors.tenant');
    expect(validatePayment({ ...paymentInput, paidOn: '2025-12-30' }, purchase, [], DEMO_ORGANIZATION_ID).paidOn).toBe('errors.tooEarly');
    expect(validatePayment({ ...paymentInput, paidOn: '' }, purchase, [], DEMO_ORGANIZATION_ID).paidOn).toBe('errors.date');
    expect(() => repo.addPayment('missing-purchase', paymentInput)).toThrow('common.validationSummary');
  });
  it('keeps cents exact through fractional payments and persists history on reload', () => {
    const { repo, purchase, storage } = setup();
    repo.addPayment(purchase.id, { ...paymentInput, amount: '0.29' });
    repo.addPayment(purchase.id, { ...paymentInput, amount: '0.01' });
    const snapshot = createLocalRepository(storage).load();
    expect(balanceCents(purchase, snapshot.payments)).toBe(9970);
    expect(snapshot.payments.filter(item => item.purchaseId === purchase.id).map(item => item.amountCents)).toEqual([29, 1]);
  });
  it('rejects altered saved history that exceeds a purchase balance', () => {
    const { repo, purchase, storage } = setup(); repo.addPayment(purchase.id, paymentInput);
    const data = JSON.parse(storage.getItem(STORAGE_KEY)); data.payments.find(item => item.purchaseId === purchase.id).amountCents = 10001;
    expect(validateStoredData(data)).toBe(false);
    storage.setItem(STORAGE_KEY, JSON.stringify(data));
    expect(() => repo.load()).toThrow('common.corruptedStorage');
  });
  it('accepts only PDF/PNG/JPEG within the documented 2 MB limit', () => {
    expect(validateFile({ type: 'application/pdf', size: MAX_FILE_BYTES })).toBeNull();
    expect(validateFile({ type: 'image/svg+xml', size: 100 })).toBe('errors.fileType');
    expect(validateFile({ type: 'image/png', size: MAX_FILE_BYTES + 1 })).toBe('errors.fileSize');
    expect(validateFile({ type: 'application/pdf', size: 0 })).toBe('errors.fileSize');
  });
});
