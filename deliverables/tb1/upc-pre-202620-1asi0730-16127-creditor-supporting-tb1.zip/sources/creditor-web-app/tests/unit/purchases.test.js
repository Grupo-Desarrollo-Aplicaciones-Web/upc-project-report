import { describe, it, expect } from 'vitest';
import { parseAmount, summarizeByCurrency } from '../../src/domain/money.js';
import { validatePurchase, filterPurchases, purchaseStatus } from '../../src/domain/purchases.js';
import { validDate } from '../../src/domain/dates.js';
import { createSeed, DEMO_ORGANIZATION_ID } from '../../src/data/seed.js';
import { createLocalRepository, STORAGE_KEY } from '../../src/data/local-repository.js';
import { memoryStorage } from './helpers.js';
const input = { supplierId: 'supplier-norte', reference: 'TEST-100', description: 'Test grocery purchase', currency: 'PEN', amount: '100.00', purchasedOn: '2026-01-01', dueOn: '2026-12-30', voucher: null };
describe('credit purchase business rules', () => {
  it('parses cents without floating point drift and accepts locale decimal separators', () => {
    expect(parseAmount('0.29')).toBe(29);
    expect(parseAmount('100,50')).toBe(10050);
    expect(parseAmount('9999999.99')).toBe(999999999);
    for (const amount of ['0', '-1', '1.234', 'abc', '10000000', '1e3', '', '1,234.50']) expect(parseAmount(amount)).toBeNull();
  });
  it('rejects impossible and ambiguous dates', () => { expect(validDate('2026-02-30')).toBe(false); expect(validDate('2024-02-29')).toBe(true); expect(validDate('2026-2-3')).toBe(false); });
  it('requires supplier in current organization and preserves currency choice', () => {
    const seed = createSeed();
    expect(validatePurchase(input, seed.suppliers, DEMO_ORGANIZATION_ID)).toEqual({});
    expect(validatePurchase({ ...input, supplierId: 'supplier-other' }, seed.suppliers, DEMO_ORGANIZATION_ID).supplierId).toBe('errors.supplier');
    expect(validatePurchase({ ...input, currency: 'EUR' }, seed.suppliers, DEMO_ORGANIZATION_ID).currency).toBe('errors.currency');
  });
  it('rejects incomplete data, reversed dates and duplicate supplier references', () => {
    const seed = createSeed();
    const errors = validatePurchase({ ...input, description: '', reference: '', amount: '', dueOn: '2025-12-01' }, seed.suppliers, DEMO_ORGANIZATION_ID);
    expect(Object.keys(errors)).toEqual(expect.arrayContaining(['description', 'reference', 'amount', 'dueOn']));
    expect(validatePurchase({ ...input, reference: 'f001-042' }, seed.suppliers, DEMO_ORGANIZATION_ID, seed.purchases).reference).toBe('errors.duplicate');
  });
  it('persists purchase and scopes supplier queries to the selected business', () => {
    const storage = memoryStorage();
    const repo = createLocalRepository(storage, DEMO_ORGANIZATION_ID, () => 'new-purchase');
    const record = repo.addPurchase(input);
    expect(record.amountCents).toBe(10000);
    const reloaded = createLocalRepository(storage).load();
    expect(reloaded.purchases.find(item => item.id === 'new-purchase')).toEqual(record);
    expect(reloaded.suppliers.some(item => item.id === 'supplier-other')).toBe(false);
    expect(() => repo.addPurchase({ ...input, reference: 'TEST-200', supplierId: 'supplier-other' })).toThrow('common.validationSummary');
  });
  it('keeps original state when browser quota rejects a write', () => {
    const storage = memoryStorage(); const repo = createLocalRepository(storage);
    const before = repo.load(); storage.setItem = () => { throw new Error('QuotaExceededError'); };
    expect(() => repo.addPurchase(input)).toThrow('common.storageError');
    expect(repo.load()).toEqual(before);
  });
  it('does not overwrite corrupted saved data silently', () => {
    const storage = memoryStorage(); storage.setItem(STORAGE_KEY, '{invalid');
    const repo = createLocalRepository(storage);
    expect(() => repo.load()).toThrow('common.corruptedStorage');
    expect(storage.getItem(STORAGE_KEY)).toBe('{invalid');
    expect(repo.reset().purchases.length).toBeGreaterThan(0);
  });
  it('separates totals by currency and filters by supplier and due date', () => {
    const seed = createSeed('2026-10-03');
    const sums = summarizeByCurrency(seed.purchases, seed.payments);
    expect(sums.find(item => item.currency === 'USD').balanceCents).toBe(92000);
    expect(sums.find(item => item.currency === 'PEN').balanceCents).toBe(780000);
    expect(filterPurchases(seed.purchases, seed.suppliers, seed.payments, { currency: 'USD', dueFrom: '2026-10-04' })).toHaveLength(1);
    expect(purchaseStatus(seed.purchases[0], seed.payments, '2026-10-03')).toBe('overdue');
    expect(purchaseStatus(seed.purchases[4], seed.payments, '2026-10-03')).toBe('settled');
  });
});
