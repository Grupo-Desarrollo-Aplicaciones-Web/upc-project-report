# CREDITOR Web Application

First local frontend for TB1: accounts payable for small businesses. Scope: US-004 (obligations), US-005 (credit purchase), US-006 (payment) and US-007 (payment history).

This repository uses GitFlow with `main`, `develop` and topic features. No remote repository or deployment is configured.

## Execution mode

TB1 uses an explicitly identified local demonstration adapter. Seed data belongs to a fictional business. Browser storage is not a remote service, authentication or multiuser persistence. The HTTP contract is prepared separately for future ASP.NET Core integration.

## Local verification

See [local review](docs/LOCAL_REVIEW.md) for setup, contracts, verified scenarios and demo limitations. GitFlow conventions are in [CONTRIBUTING](CONTRIBUTING.md).

