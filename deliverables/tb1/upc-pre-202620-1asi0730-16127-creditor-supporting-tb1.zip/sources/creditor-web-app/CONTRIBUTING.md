# Local GitFlow

`main` contains the initialized stable baseline. Work starts on `feature/<topic>` from `develop`, with Conventional Commits and focused changes. Integrate reviewed features locally with `git merge --no-ff`. Preserve feature refs until the owner reviews publication.

Use `release/<semver>` from `develop` for a reviewed delivery. A release merges into `main` and back into `develop` only when acceptance criteria are satisfied. Use `hotfix/<topic>` from `main` for a stable-version correction, integrating into both long-lived branches.

The TB1 preparation does not publish or deploy. No remote is configured. Configure author identity locally before committing. Do not rewrite previous authors or fabricate reviews, tests, meetings or sprint hours.

Before integration run `npm test`, `npm run test:e2e`, `npm run build` and `git diff --check`. Browser tests currently use locally installed Microsoft Edge headless. CI verifies unit tests and build only.
